package com.example.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.junit.runner.RunWith;

import com.example.demo.Addtion;

@RunWith(SpringRunner.class)
@SpringBootTest
public class AddtionTest {

	@Autowired
	Addtion addtion;
	
	@Test
	void testAddtion() {
		Assertions.assertEquals(11, addtion.addtion(5, 6));
	}

}
