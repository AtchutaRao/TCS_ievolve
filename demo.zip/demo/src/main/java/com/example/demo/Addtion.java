package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class Addtion {

	public int addtion(int a,int b) {
		return (a+b);
	}
}
