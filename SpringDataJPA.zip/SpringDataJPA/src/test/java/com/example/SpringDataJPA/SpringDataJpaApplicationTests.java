package com.example.SpringDataJPA;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.SpringDataJPA.entities.Student;
import com.example.SpringDataJPA.entities.StudentRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
class SpringDataJpaApplicationTests {
	
	@Autowired
	StudentRepository studentRepository;
	
	@Test
	void contextLoads() {
	}
	@Test
	public void testCreate()
	{
		Student student=new Student();
		student.setId(1L);
		student.setName("Yeduvaka");
		student.setTestScore(98);
		studentRepository.save(student);
		
		Student savedStudent=studentRepository.findById(1L).get();
		assertNotNull(savedStudent);
	}
	@Test
	public void testRead()
	{
		Student student=new Student();
		student.setId(1L);
		student.setName("Yeduvaka");
		student.setTestScore(98);
		studentRepository.save(student);
		

		assertEquals("Yeduvaka",studentRepository.findById(1L).get().getName());
	}
	@Test
	public void testUpdate()
	{
		Student student=new Student();
		student.setId(2L);
		student.setName("Venkata Ramana");
		student.setTestScore(90);
		studentRepository.save(student);
		
		Student savedStudent=studentRepository.findById(2L).get();
		student.setName("Govind");
		student.setTestScore(92);
		studentRepository.save(student);
		savedStudent=studentRepository.findById(2L).get();
		
		assertEquals("Govind",savedStudent.getName());
		assertEquals(92,savedStudent.getTestScore());
	}
	@Test
	public void testDelete()
	{
		
		
		Student student=new Student();
		student.setId(1L);
		student.setName("Yeduvaka");
		student.setTestScore(98);
		studentRepository.save(student);
		
		studentRepository.deleteAll();
		
		assertThat(studentRepository.findAll()).isEmpty();
		
	}

}
